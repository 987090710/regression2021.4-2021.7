from SalesForest import SalesForest
# from sys import argv
# pwd = argv[0]
pwd = '..\\数据集\\Serving Trays\\'
# pwd.replace(' ','_')
sft = SalesForest(pwd)
dc1,dc2= sft.loop_func()