from SalesForest import SalesForest
pwd = '..\\数据集\\Serving Trays\\'
sft = SalesForest(pwd)
sft.predict_func()