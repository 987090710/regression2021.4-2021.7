import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
from pylab import mpl
from math import sqrt 
import warnings
warnings.simplefilter('ignore', np.RankWarning)
import datetime
class SalesForest:
    '''
    load_path:文件读取路径
    output_path：文件输出路径
    '''
    def __init__(self,load_path):
        self.load_path = load_path
        self.result_pwd = str(self.load_path + 'result')
        print(load_path)
        
    def df_clearn(self,file_name):
        '''每月数据清洗
        '''
        df = pd.read_excel(self.load_path+file_name)
#         month = file_name[file_name.find(".",file_name.find(".")+1)+1:file_name.find(".",file_name.find("-")+1)+8]
        month = file_name[file_name.rfind("-")-7:file_name.rfind("-")]
        df['月份'] = month
        #删除父ASIN重复数据
        df['父体'].fillna(df['ASIN'],inplace=True)
        df.drop_duplicates(subset=['父体'],inplace=True)
        #删除月销量等于0数据
        df = df.loc[df['月销量']!=0,:]
        #删除品牌和销量相同的产品
        df['筛选项'] = df['品牌'] + df['月销量'].apply(lambda x: str(x))
        df.drop_duplicates(subset=['筛选项'],inplace=True)
        df = df[df['月销量'].notnull()]
        df.reset_index(drop=True,inplace=True)
        df['rank'] = np.arange(1,df.shape[0]+1)
#         print(df)
        return df
        
    def get_n(self,x,y):
        '''
        获取rmse最小的阶数
        '''
        RMSE={}
        for deg in np.arange(2, 21, 1):
            with warnings.catch_warnings():                 
                warnings.filterwarnings('error')         
                try:
                    a = np.polyfit(x, y, deg)
                except np.RankWarning:#终止阶数
                    break
            sume=0
            e = (np.polyval(a, x) - y )
            for i in range(len(e)):
                sume=sume+e[i]*e[i]
            Rmse=sqrt(sume/len(e))
            RMSE[deg]=Rmse
        return min(RMSE, key=RMSE.get)
        
    def poly_func(self,df,x,y):
        '''
        拟合
        '''
        n = self.get_n(x,y)#获得最合适阶数
        f1 = np.polyfit(x,y,n)
        p1 = np.poly1d(f1)
        yvals = p1(x)#预测结果
        return yvals
    
    def gaussian_kernel_fucn(self,df,x,y):
        '''
        高斯核
        '''
        num = df.shape[0]
        h0 = 0.2
        p2 = np.zeros(num)
        for i in range(num):
            dist = np.abs(x-x[i])
            gaussian_kernel = lambda d,h: np.exp(-dist**2/(2*(h**2)))/(np.sqrt(2*np.pi)*h)
            w = gaussian_kernel(dist,h0)
            p2[i] = np.sum(y*w)/np.sum(w)
        return p2
        
    def plot_out(self,x,y,month,yvals,title):
        '''
        '''
        if not os.path.exists(self.result_pwd):
            # os.remove(self.result_pwd)
            os.mkdir(self.result_pwd)
        if not os.path.exists(self.result_pwd + '\\' + title):
            # os.remove(self.result_pwd + '\\' + title)
            os.mkdir(self.result_pwd + '\\' + title)
        plt.figure()
        plot1 = plt.plot(x, y, 's',label='original values')
        plot2 = plt.plot(x, yvals, 'r',label='polyfit values')
        plt.xlabel('x')
        plt.ylabel('y')
        plt.legend(loc=4)
        plt.title(title)
        plt.rcParams["figure.dpi"] = 90
        plt.savefig('{0}\\{1}\\{2}.png'.format(self.result_pwd,title,month))
        # plt.show()
    
        

    def loop_func(self):
        '''
        数据的读取与清洗：
        1.读取数据
        2.以标题来读取报告月份
        3.对数据进行逻辑清洗
            a.将父体为空的以子ASIN填充
            b.删除月销量为0的数据
            c.使用品牌+月销量作为筛选项，将两个都相同的数据去重
            d.重新进行index并且
        
        '''
        file_list_path = self.load_path
        file_name_list = os.listdir(file_list_path)
#         col1=["p1(10)","p1(20)","p1(50)","p1(100)","p1(200)","p1(400)","p1(600)"]
#         col2=["p2(10)","p2(20)","p2(50)","p2(100)","p2(200)","p2(400)","p2(600)"]
        dc1=dict()
        dc2=dict()

        for file_name in file_name_list:
            if file_name=='result':
                pass
            print(file_name)
            df = self.df_clearn(file_name)
            x,y = df['rank'],df['月销量']
            month = df['月份'].unique()[0]
            print(month)
            if len(x) < 10:
                dc1[month] = 0
                dc2[month] = 0
            else:
                p1 = self.poly_func(df,x,y)
                dc1[month] = pd.Series(p1)
                self.plot_out(x,y,month,p1,'poly_func')
                p2 = self.gaussian_kernel_fucn(df,x,y)
                dc2[month] = pd.Series(p2)
                self.plot_out(x,y,month,p2,'gk_func')
        # print(dc1)
        # print(dc2)
        # print(type(dc1))
        # print(type(dc2))
        df1 = pd.DataFrame(dc1)
        df1.fillna(0,inplace=True)
        df1.clip(lower=0,inplace=True)
        df2 = pd.DataFrame(dc2)
        df2.fillna(0,inplace=True)
        df2.clip(lower=0,inplace=True)
        self.report_out(df1,df2,'predict')
        print(df2.shape)
        return p1,p2
    

    def predict_func(self):
        df1 = pd.read_excel('{}\\predict.xlsx'.format(self.result_pwd),sheet_name='polyfit')
        df2 = pd.read_excel('{}\\predict.xlsx'.format(self.result_pwd),sheet_name='gaussian')
        get_p_num_list = str(input("输入取数位置，如10,20,50,100... ：")).split(',')
        target_month = str(input('请输入月份，如02：')).strip()

        get_p_num_list = [int(i) for i in get_p_num_list]
        p_length = len(get_p_num_list)
        dc1 = df1.iloc[get_p_num_list,:]

        dc2 = df2.iloc[get_p_num_list,:]
        dc1_result = self.predict_clearn(dc1,target_month)
        dc2_result = self.predict_clearn(dc2,target_month)
        dc1_result = dc1_result.reset_index()
        dc2_result = dc2_result.reset_index()
        self.report_out(dc1_result,dc2_result,'coef')
    def predict_clearn(self,df,target_month):
        # print(df)
        df = pd.DataFrame(df.values.T, index=df.columns, columns=df.index)
        # print(df)
        year_list=[]
        for i in df.index.tolist():
            year = i.split('.')[0]
            if year not in year_list:
                year_list.append(year)

        df['日期'] = df.index
        df['年份'] = df['日期'].apply(lambda x : x.split('.')[0])
        df['月份'] = df['日期'].apply(lambda x : x.split('.')[1])

        data_temp = pd.DataFrame()
        for j in year_list:
            data = df.loc[df['年份']==j,:]            
            data = data.iloc[:,:data.shape[1]-3]
            print(data.iloc[int(target_month)-1,:])
            data = data.div(data.iloc[int(target_month)-1,:],axis=1)
            data_temp = pd.concat([data_temp,data],axis=0)
            print(data)
        return data_temp


    def report_out(self,df1,df2,target_name):
        # df1,df2 = self.loop_func()
        writer=pd.ExcelWriter('{}\\{}.xlsx'.format(self.result_pwd,target_name))
        df1.to_excel(writer,sheet_name = 'polyfit',index=0)
        df2.to_excel(writer,sheet_name = 'gaussian',index=0)
        writer.save()
        writer.close()




            
        # dc1 = dc1.T
        # dc2 = dc2.T
        # dc1.clip(lower=0,inplace=True)
        # dc2.clip(lower=0,inplace=True)

        # return dc1,dc2
